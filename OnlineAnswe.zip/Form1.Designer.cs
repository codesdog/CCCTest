﻿namespace 智力问答游戏
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNext = new System.Windows.Forms.Button();
            this.btnScore = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPre = new System.Windows.Forms.Button();
            this.btnEnd = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsmiSkin = new System.Windows.Forms.ToolStripDropDownButton();
            this.宝石蓝ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.翡翠之恋ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.绿色玻璃ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.永恒埃及ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.夏至未至ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.银边美丽ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.海洋的波浪ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ｍＳＮToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.默认模式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(166, 274);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(72, 24);
            this.btnNext.TabIndex = 8;
            this.btnNext.Text = "下一题";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnScore
            // 
            this.btnScore.Location = new System.Drawing.Point(324, 274);
            this.btnScore.Name = "btnScore";
            this.btnScore.Size = new System.Drawing.Size(72, 24);
            this.btnScore.TabIndex = 7;
            this.btnScore.Text = "统计成绩";
            this.btnScore.Click += new System.EventHandler(this.btnScore_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(10, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(386, 197);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "选项";
            // 
            // radioButton5
            // 
            this.radioButton5.Location = new System.Drawing.Point(6, 164);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(372, 32);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.Text = "radioButton5";
            this.radioButton5.Visible = false;
            // 
            // radioButton4
            // 
            this.radioButton4.Location = new System.Drawing.Point(8, 129);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(372, 32);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.Text = "radioButton4";
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.Location = new System.Drawing.Point(8, 94);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(372, 32);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.Location = new System.Drawing.Point(8, 59);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(372, 32);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(8, 24);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(372, 32);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(10, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 32);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(10, 274);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(72, 24);
            this.btnFirst.TabIndex = 9;
            this.btnFirst.Text = "第一题";
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPre
            // 
            this.btnPre.Location = new System.Drawing.Point(88, 274);
            this.btnPre.Name = "btnPre";
            this.btnPre.Size = new System.Drawing.Size(72, 24);
            this.btnPre.TabIndex = 10;
            this.btnPre.Text = "上一题";
            this.btnPre.Click += new System.EventHandler(this.btnPre_Click);
            // 
            // btnEnd
            // 
            this.btnEnd.Location = new System.Drawing.Point(244, 274);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(72, 24);
            this.btnEnd.TabIndex = 11;
            this.btnEnd.Text = "最后一题";
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiSkin});
            this.statusStrip1.Location = new System.Drawing.Point(0, 302);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(592, 22);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsmiSkin
            // 
            this.tsmiSkin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiSkin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.宝石蓝ToolStripMenuItem,
            this.翡翠之恋ToolStripMenuItem,
            this.绿色玻璃ToolStripMenuItem,
            this.永恒埃及ToolStripMenuItem,
            this.夏至未至ToolStripMenuItem,
            this.银边美丽ToolStripMenuItem,
            this.海洋的波浪ToolStripMenuItem,
            this.ｍＳＮToolStripMenuItem,
            this.xPToolStripMenuItem,
            this.默认模式ToolStripMenuItem});
            this.tsmiSkin.Image = global::智力问答游戏.Properties.Resources._7;
            this.tsmiSkin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiSkin.Name = "tsmiSkin";
            this.tsmiSkin.Size = new System.Drawing.Size(29, 20);
            this.tsmiSkin.Text = "皮肤";
            // 
            // 宝石蓝ToolStripMenuItem
            // 
            this.宝石蓝ToolStripMenuItem.Name = "宝石蓝ToolStripMenuItem";
            this.宝石蓝ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.宝石蓝ToolStripMenuItem.Tag = "1";
            this.宝石蓝ToolStripMenuItem.Text = "宝石的心";
            this.宝石蓝ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 翡翠之恋ToolStripMenuItem
            // 
            this.翡翠之恋ToolStripMenuItem.Name = "翡翠之恋ToolStripMenuItem";
            this.翡翠之恋ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.翡翠之恋ToolStripMenuItem.Tag = "2";
            this.翡翠之恋ToolStripMenuItem.Text = "翡翠之恋";
            this.翡翠之恋ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 绿色玻璃ToolStripMenuItem
            // 
            this.绿色玻璃ToolStripMenuItem.Name = "绿色玻璃ToolStripMenuItem";
            this.绿色玻璃ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.绿色玻璃ToolStripMenuItem.Tag = "3";
            this.绿色玻璃ToolStripMenuItem.Text = "绿色玻璃";
            this.绿色玻璃ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 永恒埃及ToolStripMenuItem
            // 
            this.永恒埃及ToolStripMenuItem.Name = "永恒埃及ToolStripMenuItem";
            this.永恒埃及ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.永恒埃及ToolStripMenuItem.Tag = "4";
            this.永恒埃及ToolStripMenuItem.Text = "永恒埃及";
            this.永恒埃及ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 夏至未至ToolStripMenuItem
            // 
            this.夏至未至ToolStripMenuItem.Name = "夏至未至ToolStripMenuItem";
            this.夏至未至ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.夏至未至ToolStripMenuItem.Tag = "5";
            this.夏至未至ToolStripMenuItem.Text = "夏至未至";
            this.夏至未至ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 银边美丽ToolStripMenuItem
            // 
            this.银边美丽ToolStripMenuItem.Name = "银边美丽ToolStripMenuItem";
            this.银边美丽ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.银边美丽ToolStripMenuItem.Tag = "7";
            this.银边美丽ToolStripMenuItem.Text = "银边美丽";
            this.银边美丽ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 海洋的波浪ToolStripMenuItem
            // 
            this.海洋的波浪ToolStripMenuItem.Name = "海洋的波浪ToolStripMenuItem";
            this.海洋的波浪ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.海洋的波浪ToolStripMenuItem.Tag = "8";
            this.海洋的波浪ToolStripMenuItem.Text = "海洋的波浪";
            this.海洋的波浪ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // ｍＳＮToolStripMenuItem
            // 
            this.ｍＳＮToolStripMenuItem.Name = "ｍＳＮToolStripMenuItem";
            this.ｍＳＮToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.ｍＳＮToolStripMenuItem.Tag = "6";
            this.ｍＳＮToolStripMenuItem.Text = "MSN";
            this.ｍＳＮToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // xPToolStripMenuItem
            // 
            this.xPToolStripMenuItem.Name = "xPToolStripMenuItem";
            this.xPToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.xPToolStripMenuItem.Tag = "9";
            this.xPToolStripMenuItem.Text = "XP";
            this.xPToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // 默认模式ToolStripMenuItem
            // 
            this.默认模式ToolStripMenuItem.Name = "默认模式ToolStripMenuItem";
            this.默认模式ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.默认模式ToolStripMenuItem.Tag = "0";
            this.默认模式ToolStripMenuItem.Text = "默认模式";
            this.默认模式ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView1.Location = new System.Drawing.Point(402, 12);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(178, 286);
            this.listView1.TabIndex = 13;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "题号";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "正确答案";
            this.columnHeader2.Width = 68;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "用户答案";
            this.columnHeader3.Width = 64;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 324);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnEnd);
            this.Controls.Add(this.btnPre);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnScore);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "智力问答游戏-下载于51aspx.com";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnScore;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPre;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripDropDownButton tsmiSkin;
        private System.Windows.Forms.ToolStripMenuItem 宝石蓝ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 翡翠之恋ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 绿色玻璃ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 永恒埃及ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 夏至未至ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 银边美丽ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 海洋的波浪ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ｍＳＮToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 默认模式ToolStripMenuItem;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}

