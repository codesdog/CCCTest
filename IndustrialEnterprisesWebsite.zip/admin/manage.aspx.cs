﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using FineUI;



namespace Webwangzhan.admin
{
    public partial class manage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin_name"] == null)
            {
                Response.Redirect("login.aspx"); 
            }
            else
            {
                if (!IsPostBack)
                {

                    BindLeftTree();
                }
            }
          }

        private void BindLeftTree(string menuType)
        {
            if (menuType == "mail")
            {
                XmlDataSource1.DataFile = "../data/menuMail.xml";
                PageContext.RegisterStartupScript("selectMenu('menu-mail');");
            }
            else if (menuType == "sys")
            {
                XmlDataSource1.DataFile = "../data/menuSYS.xml";
                PageContext.RegisterStartupScript("selectMenu('menu-sys');");
            }
            else if (menuType == "sms")
            {
                XmlDataSource1.DataFile = "../data/menusms.xml";
                PageContext.RegisterStartupScript("selectMenu('menu-sms');");
            }

            BindLeftTree();
        }

        private void BindLeftTree()
        {
            leftTree.DataSource = XmlDataSource1;
            leftTree.DataBind();
        }

        #region Events

        protected void lbtnMail_Click(object sender, EventArgs e)
        {
            BindLeftTree("mail");
        }


        protected void lbtnSYS_Click(object sender, EventArgs e)
        {
            BindLeftTree("sys");

        }


        protected void lbtnSMS_Click(object sender, EventArgs e)
        {
            BindLeftTree("sms");
        }

        #endregion

        /// <summary>
        /// 安全退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void tuichu_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("login.aspx"); 
        }

    }
}