﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HaoCodeBuilder.Model
{
    public class Views
    {
        public string Name { get; set; }
    }
}
