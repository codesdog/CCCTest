﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HaoCodeBuilder.Model
{
    public  class ConfigDirectory
    {
        /// <summary>
        /// 目录
        /// </summary>
        public string Name { get; set; }
    }
}
