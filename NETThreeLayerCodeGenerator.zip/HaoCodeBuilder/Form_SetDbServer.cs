﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HaoCodeBuilder
{
    public partial class Form_SetDbServer : Form
    {
        public Form_SetDbServer()
        {
            InitializeComponent();
        }
    }
}
