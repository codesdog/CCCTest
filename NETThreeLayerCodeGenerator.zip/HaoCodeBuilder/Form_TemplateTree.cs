﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HaoCodeBuilder
{
    public partial class Form_TemplateTree : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        public Form_TemplateTree()
        {
            InitializeComponent();
        }
    }
}
