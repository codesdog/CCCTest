﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyModel
{
    public class FeeType
    {
        private int _id;
        private string _typename;
        private string _shouzhiname;
        private string _note;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TypeName
        {
            set { _typename = value; }
            get { return _typename; }
        }
        public string ShouZhiName
        {
            set { _shouzhiname = value; }
            get { return _shouzhiname; }
        }
        public string Note
        {
            set { _note = value; }
            get { return _note; }
        }
    }
}
