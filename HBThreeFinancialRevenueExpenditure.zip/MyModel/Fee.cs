﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyModel
{
    public class Fee
    {
        private int _id;
        private string _shouzhiname;
        private string _typename;
        private decimal _costmoney;
        private string _note;
        private string _costdate;
        private string _showstate;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ShouZhiName
        {
            set { _shouzhiname = value; }
            get { return _shouzhiname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TypeName
        {
            set { _typename = value; }
            get { return _typename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public decimal CostMoney
        {
            set { _costmoney = value; }
            get { return _costmoney; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Note
        {
            set { _note = value; }
            get { return _note; }
        }
        public string CostDate
        {
            set { _costdate = value; }
            get { return _costdate; }
        }
        public string ShowState
        {
            set { _showstate = value; }
            get { return _showstate; }
        }
    }
}
