﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyModel
{
    public class User
    {
        #region Model
        private int _id;
        private string _username;
        private string _userpwd;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserName
        {
            set { _username = value; }
            get { return _username; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserPwd
        {
            set { _userpwd = value; }
            get { return _userpwd; }
        }
        #endregion Model
    }
}
