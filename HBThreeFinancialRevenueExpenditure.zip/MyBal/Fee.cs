﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace MyBal
{
    public class Fee
    {
        MyDal.Fee feeDal = new MyDal.Fee();
        public int Add(MyModel.Fee model)
        {
            return feeDal.Add(model);
        }
        public int Update(MyModel.Fee model)
        {
            return feeDal.Update(model);
        }
        public int DeleteByID(int ID)
        {
            return feeDal.Delete(ID);
        }
        public int DeleteWhere(string strwhere)
        {
            return feeDal.DeleteWhere(strwhere);
        }
        public MyModel.Fee GetByID(int ID)
        {
            return feeDal.GetModel(ID);
        }
        public DataTable GetDataTable(string strwhere)
        {
            return feeDal.GetList(strwhere);
        }
    }
}
