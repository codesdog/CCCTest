﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace MyBal
{
    public class User
    {
        MyDal.User userDal = new MyDal.User();
        public int Add(MyModel.User user)
        {
            return userDal.Add(user);
        }
        public int Update(MyModel.User user)
        {
            return userDal.Update(user);
        }
        public int DeleteByID(int ID)
        {
            return userDal.Delete(ID);
        }
        public int DeleteWhere(string strwhere)
        {
            return userDal.DeleteWhere(strwhere);
        }
        public MyModel.User GetByID(int ID)
        {
            return userDal.GetModel(ID);
        }
        public DataTable GetTable(string strwhere)
        {
            return userDal.GetList(strwhere);
        }
    }
}
