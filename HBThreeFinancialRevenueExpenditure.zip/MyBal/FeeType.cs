﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace MyBal
{
    public class FeeType
    {
        MyDal.FeeType feetypeDal = new MyDal.FeeType();
        public int Add(MyModel.FeeType model)
        {
            return feetypeDal.Add(model);
        }
        public int Update(MyModel.FeeType model)
        {
            return feetypeDal.Update(model);
        }
        public int DeleteByID(int ID)
        {
            return feetypeDal.Delete(ID);
        }
        public int DeleteWhere(string strwhere)
        {
            return feetypeDal.DeleteWhere(strwhere);
        }
        public DataTable GetDataTable(string strwhere)
        {
            return feetypeDal.GetList(strwhere);
        }
        public MyModel.FeeType GetByID(int ID)
        {
            return feetypeDal.GetModel(ID);
        }
    }
}
