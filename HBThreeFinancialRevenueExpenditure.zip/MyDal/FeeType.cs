﻿using System;
using System.Collections.Generic;
using System.Text;
using Common;
using System.Data;
using System.Data.OleDb;

namespace MyDal
{
    public class FeeType
    {
        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(MyModel.FeeType model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into tb_FeeType(");
            strSql.Append("[TypeName],[ShouZhiName],[Note])");
            strSql.Append(" values (");
            strSql.Append("@TypeName,@ShouZhiName,@Note)");
            OleDbParameter[] parameters = {
					new OleDbParameter("@TypeName", OleDbType.VarChar,200),
                new OleDbParameter("@ShouZhiName",OleDbType.VarChar,50),
                new OleDbParameter("@Note",OleDbType.VarChar,500),
            };
            parameters[0].Value = model.TypeName;
            parameters[1].Value = model.ShouZhiName;
            parameters[2].Value = model.Note;

           return  SqlHelper.ExecuteNonQuery(strSql.ToString(),parameters);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public int Update(MyModel.FeeType model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update tb_FeeType set ");
            strSql.Append("[TypeName]=@TypeName,");
            strSql.Append("[ShouZhiName]=@ShouZhiName,");
            strSql.Append("[Note]=@Note");
            strSql.Append(" where [ID]=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@TypeName", OleDbType.VarChar,200),
                new OleDbParameter("@ShouZhiName",OleDbType.VarChar,50),
                new OleDbParameter("@Note",OleDbType.VarChar,500),
                new OleDbParameter("@ID", OleDbType.Integer,4),
            };
            parameters[0].Value = model.TypeName;
            parameters[3].Value = model.ID;
            parameters[1].Value = model.ShouZhiName;
            parameters[2].Value = model.Note;

            return SqlHelper.ExecuteNonQuery(strSql.ToString(),parameters);
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public int Delete(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from tb_FeeType ");
            strSql.Append(" where ID=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@ID", OleDbType.Integer,4)
			};
            parameters[0].Value = ID;

            return SqlHelper.ExecuteNonQuery(strSql.ToString(),parameters);
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public int DeleteWhere(string strwhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from tb_FeeType ");
            strSql.Append(" where " + strwhere);
            return SqlHelper.ExecuteNonQuery(strSql.ToString());
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public MyModel.FeeType GetModel(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 * from tb_FeeType ");
            strSql.Append(" where ID=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@ID", OleDbType.Integer,4)
			};
            parameters[0].Value = ID;

            MyModel.FeeType model = new MyModel.FeeType();
            DataTable ds = SqlHelper.GetDataTabel(strSql.ToString(), parameters);
            if (ds.Rows.Count > 0)
            {
                if (ds.Rows[0]["ID"] != null && ds.Rows[0]["ID"].ToString() != "")
                {
                    model.ID = int.Parse(ds.Rows[0]["ID"].ToString());
                }
                if (ds.Rows[0]["TypeName"] != null)
                {
                    model.TypeName = ds.Rows[0]["TypeName"].ToString();
                }
                if (ds.Rows[0]["ShouZhiName"] != null)
                {
                    model.ShouZhiName = ds.Rows[0]["ShouZhiName"].ToString();
                }
                if (ds.Rows[0]["Note"] != null)
                {
                    model.Note = ds.Rows[0]["Note"].ToString();
                }
                return model;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataTable GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" FROM tb_FeeType ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return SqlHelper.GetDataTabel(strSql.ToString());
        }



        /// <summary>
        /// 获得前几行数据
        /// </summary>
        public DataTable GetList(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" * ");
            strSql.Append(" FROM tb_FeeType ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by " + filedOrder);
            return SqlHelper.GetDataTabel(strSql.ToString());
        }
    }
}
