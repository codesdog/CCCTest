﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using Common;

namespace MyDal
{
    public class User
    {
        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(MyModel.User model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into tb_User(");
            strSql.Append("UserName,UserPwd)");
            strSql.Append(" values (");
            strSql.Append("@UserName,@UserPwd)");
            strSql.Append(";select @@IDENTITY");
            OleDbParameter[] parameters = {
					new OleDbParameter("@UserName", OleDbType.VarChar,50),
					new OleDbParameter("@UserPwd", OleDbType.VarChar,50)};
            parameters[0].Value = model.UserName;
            parameters[1].Value = model.UserPwd;

            return SqlHelper.ExecuteNonQuery(strSql.ToString(), parameters);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public int Update(MyModel.User model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update tb_User set ");
            strSql.Append("UserName=@UserName,");
            strSql.Append("UserPwd=@UserPwd");
            strSql.Append(" where ID=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@UserName", OleDbType.VarChar,50),
					new OleDbParameter("@UserPwd", OleDbType.VarChar,50),
					new OleDbParameter("@ID", OleDbType.Integer,4)};
            parameters[0].Value = model.UserName;
            parameters[1].Value = model.UserPwd;
            parameters[2].Value = model.ID;

            return SqlHelper.ExecuteNonQuery(strSql.ToString(), parameters);
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public int Delete(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from tb_User ");
            strSql.Append(" where ID=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@ID", OleDbType.Integer,4)
			};
            parameters[0].Value = ID;

            return SqlHelper.ExecuteNonQuery(strSql.ToString(), parameters);
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public int DeleteWhere(string strwhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from tb_User ");
            strSql.Append(" where "+strwhere);
            return SqlHelper.ExecuteNonQuery(strSql.ToString());
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public MyModel.User GetModel(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 ID,UserName,UserPwd from tb_User ");
            strSql.Append(" where ID=@ID");
            OleDbParameter[] parameters = {
					new OleDbParameter("@ID", OleDbType.Integer,4)
			};
            parameters[0].Value = ID;

            MyModel.User model = new MyModel.User();
            DataTable ds = SqlHelper.GetDataTabel(strSql.ToString(), parameters);
            if (ds.Rows.Count > 0)
            {
                if (ds.Rows[0]["ID"] != null && ds.Rows[0]["ID"].ToString() != "")
                {
                    model.ID = int.Parse(ds.Rows[0]["ID"].ToString());
                }
                if (ds.Rows[0]["UserName"] != null)
                {
                    model.UserName = ds.Rows[0]["UserName"].ToString();
                }
                if (ds.Rows[0]["UserPwd"] != null)
                {
                    model.UserPwd = ds.Rows[0]["UserPwd"].ToString();
                }
                return model;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataTable GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ID,UserName,UserPwd ");
            strSql.Append(" FROM tb_User ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return SqlHelper.GetDataTabel(strSql.ToString());
        }
    }
}
