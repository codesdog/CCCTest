﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Common
{
    public class MessageBox
    {
        public static void ShowMes(Page p, string mes)
        {
            p.ClientScript.RegisterStartupScript(p.GetType(), "弹出对话框", "alert('" + mes + "')", true);
        }
        public static void Redirect(Page p, string url)
        {
            p.ClientScript.RegisterStartupScript(p.GetType(), "跳转页面", "location.href='" + url + "'", true);

        }
        public static void ShowMesAndRedirect(Page p, string mes, string url)
        {
            p.ClientScript.RegisterStartupScript(p.GetType(),"弹出对话框并跳转页面","alert('"+mes+"');location.href='"+url+"'",true);
        }
    }
}
