﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;

public partial class MyLogin : System.Web.UI.Page
{
    private MyBal.User userBal = new MyBal.User();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        MyModel.User user = userBal.GetByID(1);
        string username = tbUserName.Text.ToString();
        string userpwd = tbUserPwd.Text.ToString();
        if (user.UserName == username && user.UserPwd == userpwd)
        {
            Session["UserID"] = user.ID.ToString();
            MessageBox.Redirect(this, "frame/index.html");
        }
        else
        {
            MessageBox.ShowMes(this,"对不起，用户名或密码输入错误，请重试！");
        }
    }
}
