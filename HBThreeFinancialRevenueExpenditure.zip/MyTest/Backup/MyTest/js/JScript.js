﻿// JScript 文件

String.prototype.trim = function() {
 return this.replace(/(^\s*)|(\s*$)/g, "");
}

//验证不能为空
function CheckEmpty(id)
{
    var temp=document.getElementById(id);
    if(temp.value.trim().length==0)
    {//为空
    return false;
    }
    else{//不为空
    return true;
    }
}

//两次密码输入一致
function ConfirmPwd(id,id1)
{
    var value1=document.getElementById(id);
    var value2=document.getElementById(id1);
    if(value1.value==value2.value)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//验证dropdownlist
function CheckDDL(id)
{
var DDL=document.getElementById(id);
  var index=DDL.selectedIndex;   
  var Text=DDL.options[index].text;
  var Value=DDL.options[index].value;

//  document.getElementById("DropDownList1").options[document.getElementById("DropDownList1").selectedIndex].text
  if(index!=0)
  {
    return true;
  }
  else
  {
    return false;
  }
 
}

//验证金钱
function CheckMoney(id)
{
    var tem=/(^[1-9][0-9]*$)|(^((0)|([1-9][0-9]*))(.[0-9]+)$)/;
    var val=document.getElementById(id).value;
    if(tem.test(val))
    {
        return true;
    }
    else
    {
        return false;
    }
}

//正确则是黑色
function ColorIsRight(id)
{
    document.getElementById(id).style.color="#666666";
}
function ColorNotRight(id)
{
    document.getElementById(id).style.color="red";
    return false;
}
//正确则是隐藏
function VisibelIsRight(id)
{
    document.getElementById(id).style.visibility="hidden";
}
function  VisibleNotRight(id) {
    document.getElementById(id).style.visibility="visible";
    return false;
}

//验证用户信息
function CheckUser()
{
    if(CheckEmpty("tbUserName")==true)
    {
        ColorIsRight("Label1");
    }
    else
    {
        return ColorNotRight("Label1");
    }
    if(CheckEmpty("tbOldPwd")==true)
    {
        ColorIsRight("Label2");
        if(CheckEmpty("tbPwd")==true)
        {
            ColorIsRight("Label3");
            if(CheckEmpty("tbqrPwd")==true)
            {
                if(ConfirmPwd("tbPwd","tbqrPwd")==true)
                {
                    VisibelIsRight("Label4");
                }
                else
                {
                    return VisibleNotRight("Label4");
                }
            }
            else
            {
                return ColorNotRight("Label3");
            }
        }
        else
        {
            return ColorNotRight("Label2");
        }
    }
    else
    {
        ColorIsRight("Label2");
        ColorIsRight("Label3");
        VisibelIsRight("Label4");
    }
    return true;
}

//收支类型添加页面

function CheckShouZhiType()
{
    if(CheckEmpty("tbTypeName")==true)
    {
        ColorIsRight("Label2");
    }
    else
    {
       return  ColorNotRight("Label2");
    }
    return true;
}


//添加收支页面
function CheckShouZhi()
{
    if(CheckDDL("ddlType")==true)
    {
        ColorIsRight("Label2");
    }
    else
    {
        return ColorNotRight("Label2");
    }
    if(CheckEmpty("tbCostFee")==true)
    {
        ColorIsRight("Label1");
        if(CheckMoney("tbCostFee")==true)
        {
            ColorIsRight("Label1");
        }
        else
        {
            return ColorNotRight("Label1");
        }
    }
    else
    {
        return ColorNotRight("Label1");
    }
    if(CheckEmpty("tbFeeDate")==true)
    {
        ColorIsRight("Label3");
    }
    else
    {
        return ColorNotRight("Label3");
    }
    return true;
}