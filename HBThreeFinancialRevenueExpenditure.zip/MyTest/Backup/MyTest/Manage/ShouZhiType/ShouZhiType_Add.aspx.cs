﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;

public partial class Manage_ShouZhiType_ShouZhiType_Add : System.Web.UI.Page
{
    private MyBal.FeeType feetypeBal = new MyBal.FeeType();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (Request["id"] != null)
                {
                    MyModel.FeeType feetype = feetypeBal.GetByID(Convert.ToInt32(Request["id"]));
                    ddlShouZhi.Items.FindByText(feetype.ShouZhiName).Selected = true;
                    tbNote.Text = feetype.Note;
                    tbTypeName.Text = feetype.TypeName;
                    btnEdit.Text = "更新";
                }
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("");
        MyModel.FeeType feetype = new MyModel.FeeType();
        feetype.TypeName = tbTypeName.Text.ToString().Trim();
        feetype.ShouZhiName = ddlShouZhi.SelectedItem.ToString();
        feetype.Note = tbNote.Text.ToString().Trim();
        if (btnEdit.Text.ToString() == "更新")
        {
            DataTable dt = feetypeBal.GetDataTable(" ShouZhiName='" + ddlShouZhi.SelectedItem.ToString().Trim() + "' and TypeName='" + tbTypeName.Text.ToString().Trim() + "' and ID not in("+Request["id"]+")");
            if (dt.Rows.Count > 0)
            {
                MessageBox.ShowMes(this, "对不起，此收支类型名称已存在！");
            }
            else
            {
                feetype.ID = Convert.ToInt32(Request["id"]);
                int flag = feetypeBal.Update(feetype);
                if (flag > 0)
                {
                    MessageBox.ShowMesAndRedirect(this, "恭喜，更新成功！", "ShouZhiType_Manage.aspx");
                }
                else
                {
                    MessageBox.ShowMes(this, "对不起，更新失败!");
                }
            }
        }
        else
        {
            DataTable dt = feetypeBal.GetDataTable(" ShouZhiName='"+ddlShouZhi.SelectedItem.ToString().Trim()+"' and TypeName='"+tbTypeName.Text.ToString().Trim()+"'");
            if (dt.Rows.Count > 0)
            {
                MessageBox.ShowMes(this, "对不起，此收支类型名称已存在！");
            }
            else
            {
                int flag = feetypeBal.Add(feetype);
                if (flag > 0)
                {
                    MessageBox.ShowMesAndRedirect(this, "恭喜，添加成功！", "ShouZhiType_Manage.aspx");
                }
                else
                {
                    MessageBox.ShowMes(this, "对不起，添加失败!");
                }
            }
        }
    }
}
