﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;

public partial class Manage_ShouZhi_ShouZhi_Add : System.Web.UI.Page
{
    private MyBal.Fee feeBal = new MyBal.Fee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindType();
            if (Session["UserID"] != null)
            {
                if (Request["id"] != null)
                {
                    MyModel.Fee fee = feeBal.GetByID(Convert.ToInt32(Request["id"]));
                    tbNote.Text = fee.Note;
                    tbCostFee.Text = fee.CostMoney.ToString();
                    ddlShouZhi.Items.FindByText(fee.ShouZhiName).Selected = true;
                    ddlType.Items.FindByText(fee.TypeName).Selected = true;
                    tbFeeDate.Text = fee.CostDate;
                    btnEdit.Text = "更新";
                }
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    public void BindType()
    {
        SqlHelper.BindDDL(ddlType, "TypeName", "ID", "select * from tb_FeeType where ShouZhiName='"+ddlShouZhi.SelectedItem.ToString()+"'");
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("");
        MyModel.Fee fee= new MyModel.Fee();
        fee.ShouZhiName = ddlShouZhi.SelectedItem.ToString();
        fee.TypeName = ddlType.SelectedItem.ToString();
        fee.Note = tbNote.Text.ToString().Trim();
        fee.CostMoney = decimal.Parse(tbCostFee.Text.ToString().Trim());
        fee.CostDate = tbFeeDate.Text.ToString().Trim();
       
        if (btnEdit.Text.ToString() == "更新")
        {
            fee.ID = Convert.ToInt32(Request["id"]);
            int flag = feeBal.Update(fee);
            if (flag > 0)
            {
                MessageBox.ShowMesAndRedirect(this, "恭喜，更新成功！", "ShouZhi_Manage.aspx");
            }
            else
            {
                MessageBox.ShowMes(this, "对不起，更新失败!");
            }
        }
        else
        {
            fee.ShowState = "显示";
            int flag = feeBal.Add(fee);
            if (flag > 0)
            {
                MessageBox.ShowMesAndRedirect(this, "恭喜，添加成功！", "ShouZhi_Manage.aspx");
            }
            else
            {
                MessageBox.ShowMes(this, "对不起，添加失败!");
            }
        }
    }
    protected void ddlShouZhi_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindType();
    }
}
