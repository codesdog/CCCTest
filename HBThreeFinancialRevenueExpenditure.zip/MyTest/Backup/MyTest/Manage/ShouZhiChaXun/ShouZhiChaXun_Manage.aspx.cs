﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;

public partial class Manage_ShouZhiChaXun_ShouZhiChaXun_Manage : System.Web.UI.Page
{
    private MyBal.Fee feeBal = new MyBal.Fee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (Request["type"] != null)
                {
                    if (Request["startdate"] != null)
                    {
                        tbDateStart.Text = Request["startdate"].ToString();
                    }
                    if (Request["enddate"] != null)
                    {
                        tbDateEnd.Text = Request["enddate"].ToString();
                    }
                }
                Bind();
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    public void Bind()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("(select * from tb_Fee where 1>0");

        if (tbDateStart.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate>='" + tbDateStart.Text.ToString().Trim() + "'");
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate<='" + tbDateEnd.Text.ToString().Trim() + "'");
        }
        strSql.Append(") m");
        if (tbDateStart.Text.ToString().Trim() == "" && tbDateEnd.Text.ToString().Trim() == "")
        {
            int costcount = int.Parse(SqlHelper.ExecuteScalar("select Count(0) from tb_Fee").ToString());
            if (costcount > 0)
            {
                lbdate.Text = SqlHelper.ExecuteScalar("select top 1 CostDate from tb_Fee order by CostDate").ToString() + "至今";
            }
            else
            {
                lbdate.Text = "至今";
            }
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateEnd.Text.ToString().Trim() + "以前的";
        }
        if (tbDateStart.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateStart.Text.ToString().Trim() + "以后的";
        }
        if (tbDateStart.Text.ToString().Trim() != "" && tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = "从" + tbDateStart.Text.ToString().Trim() + "到" + tbDateEnd.Text.ToString().Trim();
        }


        object obshouru = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='收入'");
        lbShouRu.Text = (obshouru != DBNull.Value ? obshouru.ToString() : "0");
        object obzhichu = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='支出'");
        lbZhiChu.Text = (obzhichu != DBNull.Value ? obzhichu.ToString() : "0");
        lbYingLi.Text = (double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Bind();
    }
    protected void lbshou_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=shouru\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=shouru\";</script>");
        //}
    }
    protected void lbzhi_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=zhichu\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=zhichu\";</script>");
        //}
    }
    protected void lbzhuan_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=yingli\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=yingli\";</script>");
        //}
    }
}
