﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;

public partial class Manage_ShouZhiChaXun_ShouZhi_Manage : System.Web.UI.Page
{
    private MyBal.Fee feeBal = new MyBal.Fee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                Bind();
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    public void Bind()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("select top 100 percent * from tb_Fee where 1>0");
        if (Request["type"] != null)
        {
            switch (Request["type"])
            {
                case "shouru":
                    strSql.Append(" and ShouZhiName='收入'");
                    break;
                case "zhichu":
                    strSql.Append(" and ShouZhiName='支出'");
                    break;
                default:
                    strSql.Append(" and 1>0");
                    break;
            }
        }
        if (Request["startdate"] != "")
        {
            strSql.Append(" and CostDate>='" + Request["startdate"].ToString() + "'");
        }
        if (Request["enddate"] != "")
        {
            strSql.Append(" and CostDate<='" + Request["enddate"].ToString() + "'");
        }
        strSql.Append(" order by CostDate desc,ShouZhiName");
  
        GridView1.DataSource = SqlHelper.GetDataTabel(strSql.ToString());
        GridView1.DataBind();
    }
    protected void dladminuser_ItemCommand(object source, DataListCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "delete":
                int flag = feeBal.DeleteByID(Convert.ToInt32(dladminuser.DataKeys[e.Item.ItemIndex].ToString()));
                if (flag > 0)
                {
                    MessageBox.ShowMes(this, "已删除成功！");
                    Bind();
                }
                else
                {
                    MessageBox.ShowMes(this, "对不起，删除失败！");
                }
                break;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Bind();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Write("<script>location.href=\"ShouZhiChaXun_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"].Trim() + "&&type=fanhui\"</script>");
    }
}
