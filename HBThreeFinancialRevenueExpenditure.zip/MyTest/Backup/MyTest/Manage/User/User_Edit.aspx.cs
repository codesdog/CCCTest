﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;

public partial class Manage_User_User_Edit : System.Web.UI.Page
{
    MyBal.User userBal = new MyBal.User();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                MyModel.User user = userBal.GetByID(1);
                tbUserName.Text = user.UserName;
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        MyModel.User olduser = userBal.GetByID(1);
        MyModel.User user = new MyModel.User();
        if (tbUserName.Text.ToString().Trim() != "")
        {
            user.UserName = tbUserName.Text.ToString().Trim();
            if (tbOldPwd.Text.ToString().Trim() != "")
            {
                if (olduser.UserPwd == tbOldPwd.Text.ToString().Trim())
                {
                    user.UserPwd = tbPwd.Text.ToString().Trim();
                }
                else
                {
                    MessageBox.ShowMes(this, "对不起，原密码输入不正确！");
                    return;
                }

            }
            else
            {
                user.UserPwd = olduser.UserPwd;
            }
            user.ID = 1;
            int flag = userBal.Update(user);
            if (flag > 0)
            {
                MessageBox.ShowMes(this, "恭喜，修改成功！");
            }
            else
            {
                MessageBox.ShowMes(this,"对不起，修改失败！");
            }
        }
        else
        {
            MessageBox.ShowMes(this,"对不起，用户名不能为空！");
        }
    }
}
