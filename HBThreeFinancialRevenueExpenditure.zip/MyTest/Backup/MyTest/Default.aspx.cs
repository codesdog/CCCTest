﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    MyBal.FeeType feetypeBal = new MyBal.FeeType();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bind();
        }
    }
    private void Bind()
    {
        DataList1.DataSource = feetypeBal.GetDataTable("");
        DataList1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open ('HTMLPage.htm', 'newwindow', 'height=100, width=400, top=0, left=0, toolbar=no, menubar=no, scrollbars=no,resizable=no,location=no, status=no') </script>");
        //MyModel.FeeType feetype = new MyModel.FeeType();
        //feetype.TypeName = TextBox1.Text.ToString().Trim();
        //int flag = feetypeBal.Add(feetype);
        //if (flag > 0)
        //{
        //    Page.ClientScript.RegisterStartupScript(this.GetType(),"","alert('恭喜,添加成功!')",true);
        //    Bind();
        //}
    }
}
