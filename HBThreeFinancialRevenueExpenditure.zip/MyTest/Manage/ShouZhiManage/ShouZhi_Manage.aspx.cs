﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;
using System.Drawing;

public partial class Manage_ShouZhi_ShouZhi_Manage : System.Web.UI.Page
{
    private MyBal.Fee feeBal = new MyBal.Fee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                Bind1();
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    public void Bind()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("select top 100 percent * from tb_Fee where ShowState='显示'");
        if (tbDateStart.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate>='"+tbDateStart.Text.ToString().Trim()+"'");
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate<='"+tbDateEnd.Text.ToString().Trim()+"'");
        }
        strSql.Append(" order by CostDate desc,ShouZhiName");
        GridView1.DataSource = SqlHelper.GetDataTabel(strSql.ToString());
        GridView1.DataBind();
    }
    public void Bind1()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("select top 100 percent * from tb_Fee where ShowState='显示'");
        strSql.Append(" and Format(CostDate,'yyyy-MM-dd')='" + DateTime.Now.ToString("yyyy-MM-dd") + "'");
        strSql.Append(" order by CostDate desc,ShouZhiName");
        GridView1.DataSource = SqlHelper.GetDataTabel(strSql.ToString());
        GridView1.DataBind();
    }

    protected void dladminuser_ItemCommand(object source, DataListCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "delete":
                int flag = feeBal.DeleteByID(Convert.ToInt32(dladminuser.DataKeys[e.Item.ItemIndex].ToString()));
                if (flag > 0)
                {
                    MessageBox.ShowMes(this, "已删除成功！");
                    Bind();
                }
                else
                {
                    MessageBox.ShowMes(this, "对不起，删除失败！");
                }
                break;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Bind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("update tb_Fee set ShowState='隐藏' where CostDate between '"+tbDateStart.Text.ToString().Trim()+"' and '"+tbDateEnd.Text.ToString().Trim()+"'");
        int flag=SqlHelper.ExecuteNonQuery(strSql.ToString());
        if (flag > 0)
        {
            Bind();
        }
        else
        {
            MessageBox.ShowMes(this, "对不起，操作失败！");
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        LinkButton LinkButton1 = GridView1.Rows[e.RowIndex].FindControl("LinkButton1") as LinkButton;
        int flag = feeBal.DeleteByID(Convert.ToInt32(LinkButton1.CommandArgument));
        if (flag > 0)
        {
            Bind();
        }
        else
        {
            MessageBox.ShowMes(this, "对不起，删除失败！");
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Bind();
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
            if (CheckBox2.Checked == true)
            {
                cbox.Checked = true;
            }
            else
            {
                cbox.Checked = false;
            }
        }
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        CheckBox2.Checked = false;
        for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
            cbox.Checked = false;
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

        int count = 0;
        for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
            if (cbox.Checked == true)
            {
                int flag = feeBal.DeleteByID(Convert.ToInt32(GridView1.DataKeys[i].Value));
                if (flag > 0)
                {
                    count++;
                }
            }
        }
        if (count > 0)
        {
            Bind();
        }
    }
}
