﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Common;
using System.Text;

public partial class Manage_ShouZhiChaXun_ShouZhiChaXun_Manage : System.Web.UI.Page
{
    private MyBal.Fee feeBal = new MyBal.Fee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (Request["type"] != null)
                {
                    if (Request["startdate"] != null)
                    {
                        tbDateStart.Text = Request["startdate"].ToString();
                    }
                    if (Request["enddate"] != null)
                    {
                        tbDateEnd.Text = Request["enddate"].ToString();
                    }
                }
                Bind();
            }
            else
            {
                MessageBox.Redirect(this, "../../MyLogin.aspx");
            }
        }
    }
    public void Bind()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("(select * from tb_Fee where 1>0");

        if (tbDateStart.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate>='" + tbDateStart.Text.ToString().Trim() + "'");
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate<='" + tbDateEnd.Text.ToString().Trim() + "'");
        }
        strSql.Append(") m");
        if (tbDateStart.Text.ToString().Trim() == "" && tbDateEnd.Text.ToString().Trim() == "")
        {
            int costcount = int.Parse(SqlHelper.ExecuteScalar("select Count(0) from tb_Fee").ToString());
            if (costcount > 0)
            {
                lbdate.Text = SqlHelper.ExecuteScalar("select top 1 CostDate from tb_Fee order by CostDate").ToString() + "至今";
            }
            else
            {
                lbdate.Text = "至今";
            }
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateEnd.Text.ToString().Trim() + "以前的";
        }
        if (tbDateStart.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateStart.Text.ToString().Trim() + "以后的";
        }
        if (tbDateStart.Text.ToString().Trim() != "" && tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = "从" + tbDateStart.Text.ToString().Trim() + "到" + tbDateEnd.Text.ToString().Trim();
        }


        object obshouru = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='收入'");
        lbShouRu.Text = (obshouru != DBNull.Value ? obshouru.ToString() : "0");
        object obzhichu = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='支出'");
        lbZhiChu.Text = (obzhichu != DBNull.Value ? obzhichu.ToString() : "0");
        lbYingLi.Text = (double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString();

        Chartlet1.AppearanceStyle = (FanG.Chartlet.AppearanceStyles)System.Enum.Parse(typeof(FanG.Chartlet.AppearanceStyles), "Line_2D_StarryNight_ThinSquare_Glow_NoBorder", true);
        Chartlet1.GroupSize = 1;
        ArrayList ColorGuider = new ArrayList();
        ArrayList[] DataArray = { new ArrayList(), new ArrayList(), new ArrayList() };
        ArrayList XLabel = new ArrayList();

        //1.Set data by manual, you can read data from database use below statements
        //手动添加数据，你也可以使用下面的代码从数据库中读取数据

        //三种颜色的线
        ColorGuider.Add("金额曲线");

        //横坐标的注释
        XLabel.Add("总收入");
        XLabel.Add("总支出");
        XLabel.Add("总盈利");

        //分别给三种线添加数据，每个添加四个数据，对应横坐标数
        //Chartlet1.TipsShow = false;
        DataArray[0].Add((obshouru != DBNull.Value ? obshouru.ToString() : "0"));
        DataArray[0].Add((obzhichu != DBNull.Value ? obzhichu.ToString() : "0"));
        DataArray[0].Add((double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString());
        Chartlet1.ChartTitle.Text = "收支图表";
        Chartlet1.XLabels.UnitText = "类型";
        Chartlet1.YLabels.UnitText = "金额/元";
        Chartlet1.InitializeData(DataArray, XLabel, ColorGuider);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Bind();
    }
    protected void AT_SelectedIndexChanged(object sender, EventArgs e)
    {
        DateTime dtstart = new DateTime();
        DateTime dtend = new DateTime();
        StringBuilder strSql = new StringBuilder();
        strSql.Append("(select * from tb_Fee where 1>0");

        if (tbDateStart.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate>='" + tbDateStart.Text.ToString().Trim() + "'");
            dtstart = Convert.ToDateTime(tbDateStart.Text.Trim());
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            strSql.Append(" and CostDate<='" + tbDateEnd.Text.ToString().Trim() + "'");
            dtend = Convert.ToDateTime(tbDateEnd.Text.Trim());
        }
        if (dtend != null && dtstart != null)
        {
            if (dtstart > dtend)
            {
                MessageBox.ShowMes(this,"结束时间不能小于开始时间！");
                return;
            }
        }
        strSql.Append(") m");
        if (tbDateStart.Text.ToString().Trim() == "" && tbDateEnd.Text.ToString().Trim() == "")
        {
            int costcount = int.Parse(SqlHelper.ExecuteScalar("select Count(0) from tb_Fee").ToString());
            if (costcount > 0)
            {
                lbdate.Text = SqlHelper.ExecuteScalar("select top 1 CostDate from tb_Fee order by CostDate").ToString() + "至今";
            }
            else
            {
                lbdate.Text = "至今";
            }
        }
        if (tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateEnd.Text.ToString().Trim() + "以前的";
        }
        if (tbDateStart.Text.ToString().Trim() != "")
        {
            lbdate.Text = tbDateStart.Text.ToString().Trim() + "以后的";
        }
        if (tbDateStart.Text.ToString().Trim() != "" && tbDateEnd.Text.ToString().Trim() != "")
        {
            lbdate.Text = "从" + tbDateStart.Text.ToString().Trim() + "到" + tbDateEnd.Text.ToString().Trim();
        }


        object obshouru = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='收入'");
        lbShouRu.Text = (obshouru != DBNull.Value ? obshouru.ToString() : "0");
        object obzhichu = SqlHelper.ExecuteScalar("select sum(CostMoney) from " + strSql.ToString() + " where ShouZhiName='支出'");
        lbZhiChu.Text = (obzhichu != DBNull.Value ? obzhichu.ToString() : "0");
        lbYingLi.Text = (double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString();

        Chartlet1.AppearanceStyle = (FanG.Chartlet.AppearanceStyles)System.Enum.Parse(typeof(FanG.Chartlet.AppearanceStyles), "Bar_2D_Aurora_FlatCrystal_NoGlow_NoBorder", true);
        //Chartlet1.GroupSize = 2;
        ArrayList ColorGuider = new ArrayList();
        ArrayList[] DataArray = { new ArrayList(), new ArrayList(), new ArrayList() };
        ArrayList XLabel = new ArrayList();

        //1.Set data by manual, you can read data from database use below statements
        //手动添加数据，你也可以使用下面的代码从数据库中读取数据

        //三种颜色的线
        

        if (tbDateEnd.Text.Trim()!="" && tbDateStart.Text.Trim()!="")
        {
            TimeSpan ts0 = dtend - dtstart;
            if (AT.Text.Trim() == "")
            {
                ColorGuider.Add("金额曲线");

                //横坐标的注释
                XLabel.Add("总收入");
                XLabel.Add("总支出");
                XLabel.Add("总盈利");

                //分别给三种线添加数据，每个添加四个数据，对应横坐标数
                //Chartlet1.TipsShow = false;
                DataArray[0].Add((obshouru != DBNull.Value ? obshouru.ToString() : "0"));
                DataArray[0].Add((obzhichu != DBNull.Value ? obzhichu.ToString() : "0"));
                DataArray[0].Add((double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString());
                Chartlet1.ChartTitle.Text = "收支图表";
                Chartlet1.XLabels.UnitText = "类型";
                Chartlet1.YLabels.UnitText = "金额/元";
                Chartlet1.InitializeData(DataArray, XLabel, ColorGuider);
            }
            else if (AT.Text.Trim() == "年")
            {
                int year = dtend.Year - dtstart.Year;
                if (year == 0)
                {
                    //ColorGuider.Add(dtend.Year.ToString());

                    //XLabel.Add("年总收入");
                    //XLabel.Add("年总支出");
                    //XLabel.Add("年总收益");
                    ColorGuider.Add("年总收入");
                    ColorGuider.Add("年总支出");
                    ColorGuider.Add("年总收益");

                    XLabel.Add(dtend.Year.ToString());
                    //分别给三种线添加数据，每个添加四个数据，对应横坐标数
                    //Chartlet1.TipsShow = false;
                    object obshouru1 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and year(CostDate)='" + dtend.Year.ToString() + "' ) m where ShouZhiName='收入'");
                    string shouru = (obshouru1 != DBNull.Value ? obshouru1.ToString() : "0");
                    object obzhichu2 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and year(CostDate)='" + dtend.Year.ToString() + "' ) m where ShouZhiName='支出'");
                    string zhichu = (obzhichu2 != DBNull.Value ? obzhichu2.ToString() : "0");
                    string shouyi = (double.Parse(shouru) - double.Parse(zhichu)).ToString();

                    DataArray[0].Add(shouru);
                    DataArray[1].Add(zhichu);
                    DataArray[2].Add(shouyi);
                }
                else
                {
                    ColorGuider.Add("年总收入");
                    ColorGuider.Add("年总支出");
                    ColorGuider.Add("年总收益");

                    for (int i = 0; i <= year; i++)
                    {
                        XLabel.Add((dtstart.Year + i).ToString());

                        object obshouru1 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and year(CostDate)='" + (dtstart.Year + i).ToString() + "' ) m where ShouZhiName='收入'");
                        string shouru = (obshouru1 != DBNull.Value ? obshouru1.ToString() : "0");
                        object obzhichu2 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and year(CostDate)='" + (dtstart.Year + i).ToString() + "' ) m where ShouZhiName='支出'");
                        string zhichu = (obzhichu2 != DBNull.Value ? obzhichu2.ToString() : "0");
                        string shouyi = (double.Parse(shouru) - double.Parse(zhichu)).ToString();

                        DataArray[0].Add(shouru);
                        DataArray[1].Add(zhichu);
                        DataArray[2].Add(shouyi);
                    }
                }

                
                Chartlet1.ChartTitle.Text = "收支图表";
                Chartlet1.XLabels.UnitText = "年份";
                Chartlet1.YLabels.UnitText = "金额/元";
                Chartlet1.InitializeData(DataArray, XLabel, ColorGuider);
            }
            else if (AT.Text.Trim() == "月")
            {
                
                
                ColorGuider.Add("年总收入");
                ColorGuider.Add("年总支出");
                ColorGuider.Add("年总收益");

                int i = 0;
                while (dtstart.AddMonths(i).ToString("yyyy-MM") != dtend.AddMonths(1).ToString("yyyy-MM"))
                {
                    XLabel.Add(dtstart.AddMonths(i).ToString("yyyy-MM"));

                    object obshouru1 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and format(CostDate,'yyyy-MM')='" + dtstart.AddMonths(i).ToString("yyyy-MM") + "' ) m where ShouZhiName='收入'");
                    string shouru = (obshouru1 != DBNull.Value ? obshouru1.ToString() : "0");
                    object obzhichu2 = SqlHelper.ExecuteScalar("select sum(CostMoney) from (select * from tb_Fee where 1>0 and format(CostDate,'yyyy-MM')='" + dtstart.AddMonths(i).ToString("yyyy-MM") + "' ) m where ShouZhiName='支出'");
                    string zhichu = (obzhichu2 != DBNull.Value ? obzhichu2.ToString() : "0");
                    string shouyi = (double.Parse(shouru) - double.Parse(zhichu)).ToString();

                    DataArray[0].Add(shouru);
                    DataArray[1].Add(zhichu);
                    DataArray[2].Add(shouyi);
                    i++;
                }

                Chartlet1.ChartTitle.Text = "收支图表";
                Chartlet1.XLabels.UnitText = "年份";
                Chartlet1.YLabels.UnitText = "金额/元";
                Chartlet1.InitializeData(DataArray, XLabel, ColorGuider);
            }
        }
        else
        {
            ColorGuider.Add("金额曲线");

            //横坐标的注释
            XLabel.Add("总收入");
            XLabel.Add("总支出");
            XLabel.Add("总盈利");

            //分别给三种线添加数据，每个添加四个数据，对应横坐标数
            //Chartlet1.TipsShow = false;
            DataArray[0].Add((obshouru != DBNull.Value ? obshouru.ToString() : "0"));
            DataArray[0].Add((obzhichu != DBNull.Value ? obzhichu.ToString() : "0"));
            DataArray[0].Add((double.Parse(lbShouRu.Text.ToString()) - double.Parse(lbZhiChu.Text.ToString())).ToString());
            Chartlet1.ChartTitle.Text = "收支图表";
            Chartlet1.XLabels.UnitText = "类型";
            Chartlet1.YLabels.UnitText = "金额/元";
            Chartlet1.InitializeData(DataArray, XLabel, ColorGuider);
        }
    }
    public int GetMonth( DateTime dtbegin,DateTime dtend)
    {
        int Month = 0;
        if ((dtend.Year - dtbegin.Year) == 0)
        {
            Month = dtend.Month - dtbegin.Month;
        }
        if ((dtend.Year - dtbegin.Year) >= 1)
        {
            if (dtend.Month - dtbegin.Month < 0)
            {
                Month = (dtend.Year - dtbegin.Year - 1) * 12 + (12 - dtbegin.Month) + dtend.Month + 1;
            }
            else
            {
                Month = (dtend.Year - dtbegin.Year) * 12 + dtend.Month - dtbegin.Month + 1;
            }
        }
        return Month;
    }

    protected void lbshou_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=shouru\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=shouru\";</script>");
        //}
    }
    protected void lbzhi_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=zhichu\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=zhichu\";</script>");
        //}
    }
    protected void lbzhuan_Click(object sender, EventArgs e)
    {
        //if (Request["type"] != null)
        //{
        //    Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + Request["startdate"] + "&&enddate=" + Request["enddate"] + "&&type=yingli\";</script>");
        //}
        //else
        //{
            Response.Write("<script>location.href=\"ShouZhi_Manage.aspx?startdate=" + tbDateStart.Text.ToString().Trim() + "&&enddate=" + tbDateEnd.Text.ToString().Trim() + "&&type=yingli\";</script>");
        //}
    }
}
