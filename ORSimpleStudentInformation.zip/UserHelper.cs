﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Student_MI
{
    class UserHelper
    {
        public static string user = "";
        public static UserType userType;
    }
    // 下载于www.51aspx.com
    public enum UserType
    {
        Admin,
        Student,
        Teacher
    }
}