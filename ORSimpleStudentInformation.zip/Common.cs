﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Student_MI
{
    public class Common
    {
        public static bool Login = false;
    }
}
