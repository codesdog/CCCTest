﻿namespace Student_MI
{
    partial class FormMainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMainWindow));
            this.lbExit = new System.Windows.Forms.Label();
            this.lbMinSize = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbStudent = new System.Windows.Forms.Label();
            this.lbCourse = new System.Windows.Forms.Label();
            this.lbScore = new System.Windows.Forms.Label();
            this.lbAccount = new System.Windows.Forms.Label();
            this.lbMenu = new System.Windows.Forms.Label();
            this.lbAbout = new System.Windows.Forms.Label();
            this.lbInfo = new System.Windows.Forms.Label();
            this.lbTime = new System.Windows.Forms.Label();
            this.lbStudent2 = new System.Windows.Forms.Label();
            this.lbCourse2 = new System.Windows.Forms.Label();
            this.lbScore2 = new System.Windows.Forms.Label();
            this.lbAccount2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbExit
            // 
            this.lbExit.AutoSize = true;
            this.lbExit.BackColor = System.Drawing.Color.Transparent;
            this.lbExit.Location = new System.Drawing.Point(764, 2);
            this.lbExit.Name = "lbExit";
            this.lbExit.Size = new System.Drawing.Size(29, 12);
            this.lbExit.TabIndex = 0;
            this.lbExit.Text = "    ";
            this.lbExit.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbExit_MouseMove);
            this.lbExit.Click += new System.EventHandler(this.lbExit_Click);
            // 
            // lbMinSize
            // 
            this.lbMinSize.AutoSize = true;
            this.lbMinSize.BackColor = System.Drawing.Color.Transparent;
            this.lbMinSize.Location = new System.Drawing.Point(739, 2);
            this.lbMinSize.Name = "lbMinSize";
            this.lbMinSize.Size = new System.Drawing.Size(23, 12);
            this.lbMinSize.TabIndex = 1;
            this.lbMinSize.Text = "   ";
            this.lbMinSize.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbMinSize_MouseMove);
            this.lbMinSize.Click += new System.EventHandler(this.lbMinSize_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 492);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "学生管理系统准备就绪";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(30, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "学生信息管理系统";
            // 
            // lbStudent
            // 
            this.lbStudent.AutoSize = true;
            this.lbStudent.BackColor = System.Drawing.Color.Transparent;
            this.lbStudent.Location = new System.Drawing.Point(16, 23);
            this.lbStudent.Name = "lbStudent";
            this.lbStudent.Size = new System.Drawing.Size(71, 72);
            this.lbStudent.TabIndex = 4;
            this.lbStudent.Text = "           \r\n           \r\n           \r\n           \r\n           \r\n           ";
            this.lbStudent.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbStudent_MouseMove);
            this.lbStudent.Click += new System.EventHandler(this.lbStudent_Click);
            // 
            // lbCourse
            // 
            this.lbCourse.AutoSize = true;
            this.lbCourse.BackColor = System.Drawing.Color.Transparent;
            this.lbCourse.Location = new System.Drawing.Point(100, 23);
            this.lbCourse.Name = "lbCourse";
            this.lbCourse.Size = new System.Drawing.Size(71, 72);
            this.lbCourse.TabIndex = 4;
            this.lbCourse.Text = "           \r\n           \r\n           \r\n           \r\n           \r\n           ";
            this.lbCourse.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbCourse_MouseMove);
            this.lbCourse.Click += new System.EventHandler(this.lbCourse_Click);
            // 
            // lbScore
            // 
            this.lbScore.AutoSize = true;
            this.lbScore.BackColor = System.Drawing.Color.Transparent;
            this.lbScore.Location = new System.Drawing.Point(184, 23);
            this.lbScore.Name = "lbScore";
            this.lbScore.Size = new System.Drawing.Size(71, 72);
            this.lbScore.TabIndex = 4;
            this.lbScore.Text = "           \r\n           \r\n           \r\n           \r\n           \r\n           ";
            this.lbScore.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbScore_MouseMove);
            this.lbScore.Click += new System.EventHandler(this.lbScore_Click);
            // 
            // lbAccount
            // 
            this.lbAccount.AutoSize = true;
            this.lbAccount.BackColor = System.Drawing.Color.Transparent;
            this.lbAccount.Location = new System.Drawing.Point(268, 23);
            this.lbAccount.Name = "lbAccount";
            this.lbAccount.Size = new System.Drawing.Size(71, 72);
            this.lbAccount.TabIndex = 4;
            this.lbAccount.Text = "           \r\n           \r\n           \r\n           \r\n           \r\n           ";
            this.lbAccount.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbAccount_MouseMove);
            this.lbAccount.Click += new System.EventHandler(this.lbAccount_Click);
            // 
            // lbMenu
            // 
            this.lbMenu.AutoSize = true;
            this.lbMenu.BackColor = System.Drawing.Color.Transparent;
            this.lbMenu.Location = new System.Drawing.Point(194, 233);
            this.lbMenu.Name = "lbMenu";
            this.lbMenu.Size = new System.Drawing.Size(173, 48);
            this.lbMenu.TabIndex = 5;
            this.lbMenu.Text = "                            \r\n                            \r\n                     " +
                "       \r\n                            ";
            this.lbMenu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbMenu_MouseMove);
            this.lbMenu.Click += new System.EventHandler(this.lbMenu_Click);
            // 
            // lbAbout
            // 
            this.lbAbout.AutoSize = true;
            this.lbAbout.BackColor = System.Drawing.Color.Transparent;
            this.lbAbout.Location = new System.Drawing.Point(175, 345);
            this.lbAbout.Name = "lbAbout";
            this.lbAbout.Size = new System.Drawing.Size(179, 12);
            this.lbAbout.TabIndex = 6;
            this.lbAbout.Text = "                             ";
            this.lbAbout.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbAbout_MouseMove);
            this.lbAbout.Click += new System.EventHandler(this.lbAbout_Click);
            // 
            // lbInfo
            // 
            this.lbInfo.AutoSize = true;
            this.lbInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbInfo.Location = new System.Drawing.Point(16, 552);
            this.lbInfo.Name = "lbInfo";
            this.lbInfo.Size = new System.Drawing.Size(53, 12);
            this.lbInfo.TabIndex = 7;
            this.lbInfo.Text = "登录人：";
            // 
            // lbTime
            // 
            this.lbTime.AutoSize = true;
            this.lbTime.BackColor = System.Drawing.Color.Transparent;
            this.lbTime.Location = new System.Drawing.Point(563, 552);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(65, 12);
            this.lbTime.TabIndex = 8;
            this.lbTime.Text = "当前时间：";
            // 
            // lbStudent2
            // 
            this.lbStudent2.AutoSize = true;
            this.lbStudent2.BackColor = System.Drawing.Color.Transparent;
            this.lbStudent2.Location = new System.Drawing.Point(85, 420);
            this.lbStudent2.Name = "lbStudent2";
            this.lbStudent2.Size = new System.Drawing.Size(83, 12);
            this.lbStudent2.TabIndex = 9;
            this.lbStudent2.Text = "             ";
            this.lbStudent2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbStudent2_MouseMove);
            this.lbStudent2.Click += new System.EventHandler(this.lbStudent2_Click);
            // 
            // lbCourse2
            // 
            this.lbCourse2.AutoSize = true;
            this.lbCourse2.BackColor = System.Drawing.Color.Transparent;
            this.lbCourse2.Location = new System.Drawing.Point(191, 420);
            this.lbCourse2.Name = "lbCourse2";
            this.lbCourse2.Size = new System.Drawing.Size(83, 12);
            this.lbCourse2.TabIndex = 9;
            this.lbCourse2.Text = "             ";
            this.lbCourse2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbCourse2_MouseMove);
            this.lbCourse2.Click += new System.EventHandler(this.lbCourse2_Click);
            // 
            // lbScore2
            // 
            this.lbScore2.AutoSize = true;
            this.lbScore2.BackColor = System.Drawing.Color.Transparent;
            this.lbScore2.Location = new System.Drawing.Point(296, 420);
            this.lbScore2.Name = "lbScore2";
            this.lbScore2.Size = new System.Drawing.Size(83, 12);
            this.lbScore2.TabIndex = 9;
            this.lbScore2.Text = "             ";
            this.lbScore2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbScore2_MouseMove);
            this.lbScore2.Click += new System.EventHandler(this.lbScore2_Click);
            // 
            // lbAccount2
            // 
            this.lbAccount2.AutoSize = true;
            this.lbAccount2.BackColor = System.Drawing.Color.Transparent;
            this.lbAccount2.Location = new System.Drawing.Point(397, 420);
            this.lbAccount2.Name = "lbAccount2";
            this.lbAccount2.Size = new System.Drawing.Size(83, 12);
            this.lbAccount2.TabIndex = 9;
            this.lbAccount2.Text = "             ";
            this.lbAccount2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbAccount2_MouseMove);
            this.lbAccount2.Click += new System.EventHandler(this.lbAccount2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(747, 552);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "熊猫制作";
            // 
            // FormMainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(804, 575);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbAccount2);
            this.Controls.Add(this.lbScore2);
            this.Controls.Add(this.lbCourse2);
            this.Controls.Add(this.lbStudent2);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.lbInfo);
            this.Controls.Add(this.lbAbout);
            this.Controls.Add(this.lbMenu);
            this.Controls.Add(this.lbAccount);
            this.Controls.Add(this.lbScore);
            this.Controls.Add(this.lbCourse);
            this.Controls.Add(this.lbStudent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbMinSize);
            this.Controls.Add(this.lbExit);
            this.Name = "FormMainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "学生信息管理系统";
            this.Load += new System.EventHandler(this.FormMainWindow_Load);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FormMainWindow_MouseUp);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormMainWindow_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FormMainWindow_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbExit;
        private System.Windows.Forms.Label lbMinSize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbStudent;
        private System.Windows.Forms.Label lbCourse;
        private System.Windows.Forms.Label lbScore;
        private System.Windows.Forms.Label lbAccount;
        private System.Windows.Forms.Label lbMenu;
        private System.Windows.Forms.Label lbAbout;
        private System.Windows.Forms.Label lbInfo;
        private System.Windows.Forms.Label lbTime;
        private System.Windows.Forms.Label lbStudent2;
        private System.Windows.Forms.Label lbCourse2;
        private System.Windows.Forms.Label lbScore2;
        private System.Windows.Forms.Label lbAccount2;
        private System.Windows.Forms.Label label3;
    }
}