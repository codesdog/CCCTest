document.write('<a href="/adurl.asp?id=9" target="_self"><img src="/uploadfile/201006/20100604165344247.jpg" width="270" height="146"  title=""></a>')
