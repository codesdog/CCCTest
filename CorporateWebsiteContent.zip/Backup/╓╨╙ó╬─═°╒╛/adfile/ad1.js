document.write('<a href="\adurl.asp?id=1" target="_blank"><img src="/images/ad.gif" width="500" height="70"  title=""></a>')
