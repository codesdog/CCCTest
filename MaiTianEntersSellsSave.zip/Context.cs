﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HDManagementSoft
{
    class Context
    {
        public static int uid=0;
        public static string uname=string.Empty;
        public static bool isC;
    }
}
